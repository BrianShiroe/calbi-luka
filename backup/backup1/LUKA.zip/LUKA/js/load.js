window.addEventListener("load", function() {
    document.querySelector(".gooey").style.display = "none";
});