An example for logging to a CSV file and viewing the content with the browser.
It is also possible to modify or download the file.

![image](https://github.com/cotestatnt/esp-fs-webserver/assets/27758688/a776a217-f634-480c-873c-8914e82f87e3)